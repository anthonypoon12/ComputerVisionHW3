Anthony Poon
Computational Vision Homework 3

1. All four parts of the assignment have been completed.
2. Have some problems when set very low thresholds in part 1. 
3. All programs runs as directed in assignment details.
4. Input files same as the ones provided.

Program_1 Edge image
    - Filter used is: Sobel 3x3 operator

Program_2 Edge thresholding.
    - The threshold used is: 40

Program_3 Computation of the Hough image
    
Program_4 Line detection
    - The threshold used is: 150
    - There are some line that are not an exact match